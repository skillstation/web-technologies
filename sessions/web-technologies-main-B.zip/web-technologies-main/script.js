function showAlert(){
        alert("Thanks for visiting Skill Station Academy!");
      }
