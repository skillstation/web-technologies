## PROJECT 01

**PROJECT STRUCTURE**

```
project-folder/
├── index.html
├── style.css
└── script.js
```

```
skillstation.org/
├──/downloads
├──/iitjee
├──/neet
├──/tuitions
├──/placements-and-training
├──/contact-us
```

## TASK LIST

Add the number 5 and 3 using googles appscript editor window; 

Read the number from column A of the given google spreadsheet and find the square of it; then writ it the the column B; ❌

Create a github repo and host the given project using github pages

Create a github repo and create a new file index.html; paste the following given code and host them in github pages;

Create a simple wepage in one or two sections and run in local server

Enhance the given website by modifying the css file; As per the instructions given

Add a Js function to index.html file - where upon clicking contact-us button - a popup window with following allert message should be shown. 

For the given project folder - restructure the project with index.html, style.css and script.js file

Download the gihub project from the below web-url and run them locally using VSCode and Live Server

Create multiple pages and add to naviagation menu

Add back navigation home menu in all the sub-pages ❌

Modify the given content to the project as per the contents given below ❌

Add the numbers 3 and 5 using PHP script; 

Use PHP to dynamically edit the given website contents;

Install the wordpress in your local machine; 

Show demo on how to use plugins; 

In your given wordpress project; install any given theme and build your index.html page; 

Host the given project using AES ec2 instance ❌

Host the given project using netlify app ❌

Configure your DNS Server with the given domain name ❌

Rebuild the given index.html using React application ❌

Rebuild the given index.html using Flutter application ❌

Store the form data collected in the page to yor SQL Database; 

Create the MySQL databsase with the following table; 

Extract the given information from the MySQL database; using the querry below

## REFERENCES

❌ Task not completed

✔️ Task completed