## PROJECT 01

**PROJECT STRUCTURE**

```
project-folder/
├── index.html
├── style.css
└── script.js
```
